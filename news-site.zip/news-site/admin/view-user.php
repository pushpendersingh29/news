<?php
include('header.php');
include('config.php');
if($_SESSION['role'] == '0'){
    header("Location:post.php");
  }

$user_id = $_GET['id'];

$sql = "SELECT * FROM `user` WHERE `user_id` = '$user_id'";

$result = mysqli_query($con,$sql);

$res = mysqli_fetch_array($result);

?>
<body>
	<h2 class="text-center" style="background: black; color: #fff;">This is <?php echo $res['first_name']." ".$res['last_name']; ?>'s Record</h2>
	<table class="table table-bordered table-hovered table-striped content-table" style="margin: 20px;">
		<tr>
			<th>Id:</th>
			<td><?php echo $res['user_id']?></td>
		</tr>
		<tr>
			<th>Name:</th>
			<td><?php echo $res['first_name']." ".$res['last_name']; ?></td>
		</tr>
		<tr>
			<th>Username:</th>
			<td><?php echo $res['username']?></td>
		</tr>
		<tr>
			<th>Password:</th>
			<td><?php echo $res['password']?></td>
		</tr>
		<tr>
			<th>Role:</th>
			<td><?php 
				if($res['role'] == 1){
					echo "Admin";
				}
				else {
					echo "Normal";
				}

			?></td>
		</tr>
	</table>

<?php
	include('footer.php');
?>