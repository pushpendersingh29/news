<?php
include('config.php');
if($_SESSION['role'] == '0'){
    header("Location:post.php");
  }

$user_id = $_GET['id'];

$sql = "DELETE FROM `user` WHERE `user_id`='$user_id'";

if(mysqli_query($con,$sql)){
	header('location:users.php');
}
else{
	echo "<p style='color:green;text-align:center;margin:10px 0;'>Record not deleted.</p>";
}
mysqli_close($con);

?>