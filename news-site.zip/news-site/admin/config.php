<?php

//Database Connection
//Database Name = news-site
//User Name = root

$con = mysqli_connect("localhost","root","","news-site") or die("Connection Failed". mysqli_connect_eroor());

?>