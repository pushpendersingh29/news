<?php

//Database Connection
//Database Name = news-site
//User Name = root

$hostname = "http://localhost/news-site";

$con = mysqli_connect("localhost","root","","news-site") or die("Connection Failed". mysqli_connect_error());

?>