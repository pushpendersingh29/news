-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 11, 2021 at 02:47 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `news-site`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(100) NOT NULL,
  `post` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `category_name`, `post`) VALUES
(30, 'Sports', 2),
(31, 'Business', 2),
(32, 'Entertainment', 1),
(33, 'Politics', 0),
(34, 'Health', 1);

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `post_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `category` varchar(100) NOT NULL,
  `post_date` varchar(50) NOT NULL,
  `author` int(11) NOT NULL,
  `post_img` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`post_id`, `title`, `description`, `category`, `post_date`, `author`, `post_img`) VALUES
(39, 'Post 34', '                                                                                                    jfdfsjlfjdfajl                                                                                ', '31', '10 May, 2021', 24, '3.jpg'),
(37, 'another test ', 'dsfsfdsfs', '31', '10 May, 2021', 24, '1.jpg'),
(41, 'Normal User Test Post', 'asdasdsadasdsa         ', '30', '10 May, 2021', 26, '3.jpg'),
(42, 'New Post', '                    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.                             ', '32', '11 May, 2021', 24, '1.jpg'),
(43, 'IPL 2021: Practice options in Delhi and Ahmedabad may have led to breach in Covid protocols', 'NEW DELHI: The Indian cricket board\'s decision to host the second phase of the Indian Premier League (IPL) matches in cities with no alternate T20-specific practice facilities may have caused the breach in Covid protocols, it has emerged.\r\nDelhi and Ahmedabad cities with rapidly increasing Covid cases hosted the second phase and the positive cases among players and staff that led to the postponement of the tournament emerged during matches in those cities. Besides, the two cities struggled for alternate practice facilities for teams.\r\n\"There is a belief within many Board of Control for Cricket of India (BCCI) and state officials that the decision to take the second phase to Delhi and Ahmedabad was wrong. There were four teams in each city and except for the main ground, which is an international-level facility and hosted matches, the alternate facilities meant for practice were open to exposure to Covid-19,\" an official in the know of things told IANS.\r\nWhile in Delhi, teams like the Chennai Super Kings used the Roshanara Club grounds for practice, those in Ahmedabad were forced to use Gujarat College ground.\r\nBoth venues are in congested or old parts of the city. The practice facility at the Motera ground in Ahmedabad has another problem. Since the construction of annexe grounds and full facilities isn\'t complete, the available facility is not suited to practice big shots needed in T20 cricket.\r\n\"The problem with the newly-built Narendra Modi Stadium in Motera is that the adjoining grounds and facilities are still under construction. While it will be a state-of-the-art facility with multiple grounds, it is not yet completed. The teams can\'t use the current practice nets as it is not suitable for big hitting needed during T20 practice. It is okay for Test matches or first-class cricket practice,\" said the official.\r\n\"So, taking players to Gujarat College ground was fraught with risk as there are so many people like the maalis (gardeners), security guard and others. It was easy to get infected,\" he pointed out. As many as three teams, including the worst-affected Kolkata Knight Riders (KKR), practiced there. Four KKR players tested positive.\r\nDelhi\'s Roshanara Club, where the BCCI was founded over 90 years ago, is in the middle of a thickly populated area, and one has to make way through crowded streets to reach there.\r\n\"The Roshanara Club in Delhi is also a club which is not suited for practice for IPL franchise. Besides, you have local staff that can easily infect the players or staff,\" said the official.\r\nDelhi has two Palam grounds which are spacious and secure, away from the city as well. There might have been issues with some aspects of the facilities there, although it has hosted international teams\' practice in the past. Closer to the IPL teams\' hotels is Jamia Millia Islamia ground, which is secure and has excellent dressing rooms, though the pitches could be an issue there.\r\n\"Shifting the tournament to Delhi and Ahmedabad opened the tournament to Covid-19 exposure,\" the official said.\r\nThe third IPL phase was to be held in Kolkata and Bengaluru. Even though Bangalore is facing a huge Covid-19 threat, it has some good facilities for practice. Besides the Chinnaswamy Stadium, where the matches were to be hosted, it has multiple grounds in Alur on the city\'s outskirts.', '30', '11 May, 2021', 25, 'ipl-2021.png'),
(44, 'India COVID cases hold close to record highs as calls widen for national lockdown', 'Indian coronavirus infections and deaths held close to record daily highs on Monday, increasing calls for the government of Prime Minister Narendra Modi to lock down the worldâ€™s second-most populous country.\r\n\r\nThe 366,161 new infections and 3,754 deaths reported by the health ministry were off a little from recent peaks, taking Indiaâ€™s tally to 22.66 million with 246,116 deaths as hospitals run out of oxygen and beds and morgues and crematoria overflow.\r\nExperts have said India\'s actual figures could be far higher than reported.\r\n\r\nSunday\'s 1.47 million tests for COVID-19 were this month\'s lowest yet, data from the state-run Indian Council of Medical Research showed. The figure compared with a daily average of 1.7 million for the first eight days of May.\r\n\r\nThe number of positive results from the tests was not immediately clear, however.\r\nMany states have imposed strict lockdowns over the last month while others have placed curbs on movement and shut cinemas, restaurants, pubs and shopping malls.\r\n\r\nBut pressure is mounting on Modi to announce a nationwide lockdown as he did during the first wave of infections last year.\r\n\r\nHe is battling criticism for allowing huge gatherings at a religious festival and holding large election rallies during the past two months even as cases surged.\r\n\r\n\"A failure of governance of epic and historic proportions,\" Vipin Narang, a political science professor at the Massachusetts Institute of Technology (MIT) in the United States, said on Twitter.\r\n\r\nSonia Gandhi, the chief of the main opposition Congress party, blamed the government for abdicating its responsibility by leaving vaccinations to states, Reuters partner ANI said on Twitter.\r\nDelhi\'s health minister said the city was running out of vaccines, with just three to four days of supplies remaining of AstraZeneca (AZN.L), made by the Serum Institute of India and branded Covishield, the NDTV news channel reported.\r\n\r\nBy Monday, the world\'s largest vaccine-producing nation had fully vaccinated just over 34.8 million, or about 2.5%, of a population of about 1.35 billion, government data shows.\r\nSHUT DOWN NEEDED\r\n\r\nOn Sunday, top White House coronavirus adviser Dr. Anthony Fauci said he had advised Indian authorities they needed to shut down.\r\n\r\n\"Youâ€™ve got to shut down,\" Fauci said on ABC\'s \"This Week\" television show. \"I believe several of the Indian states have already done that, but you need to break the chain of transmission. And one of the ways to do that is to shut down.\"\r\n\r\nThe Indian Medical Association (IMA) has also called for a \"complete, well-planned, pre-announced\" lockdown.\r\n\r\nNew Delhi entered a fourth week of lockdown, with tougher curbs such as the shutdown of the suburban rail network, while residents scrambled for scarce hospital beds and oxygen supplies.\r\n\r\n\"This is not the time to be lenient,\" Delhi chief minister Arvind Kejriwal said on Sunday.\r\n\r\n\"This phase is so tough, this wave is so dangerous, so many people are dying...the priority at this hour is to save lives,\" he said in a televised address.\r\n\r\nLate on Sunday, the northern state of Uttarakhand said it would impose curfew from Tuesday until May 18, just days after mass religious gatherings held in the state became virus super spreading events.\r\n\r\nShops selling essential food items will stay open for some hours in the morning, while malls, gyms, theatres, bars and liquor shops are among the enterprises that will be shut, the government said.\r\nOrganisers of the popular and lucrative Indian Premier League (IPL) cricket tournament conceded the remaining games would have to be played overseas after having suspended the contest over the virus this month.\r\n\r\nGlobal support, in the form of oxygen cylinders and concentrators, ventilators and other medical gear, has poured in.\r\n\r\nU.S. company Eli Lilly and Co (LLY.N) said it had signed licensing deals with Indian drugmakers, such as Cipla Ltd (CIPL.NS), Lupin and Sun Pharma to make and sell its arthritis drug baricitinib for the treatment of COVID-19 patients.\r\n\r\nIndiaâ€™s drug regulator has approved the drug for restricted emergency use in combination with remdesivir for hospitalised adult sufferers requiring oxygen.', '34', '11 May, 2021', 25, 'corona-virus.png');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `websitename` varchar(60) NOT NULL,
  `logo` varchar(50) NOT NULL,
  `footerdesc` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`websitename`, `logo`, `footerdesc`) VALUES
('News Website', 'news.jpg', ' Copyright 2021 News | Powered By <a href=\"#\">Pushpender Singh Rathore</a>');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `username` varchar(30) DEFAULT NULL,
  `password` varchar(40) DEFAULT NULL,
  `role` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `first_name`, `last_name`, `username`, `password`, `role`) VALUES
(24, 'Pushpender', 'Singh', 'pushpender', '12345', 1),
(25, 'Kunal', 'Rathore', 'kunal', '12345', 1),
(26, 'Rahul', 'Kumar', 'rahul', '12345', 0),
(27, 'Rohit', 'Singh', 'rohit', '12345', 0),
(37, 'Manish', 'Singh', 'manish', '12345', 0),
(36, 'Sumit', 'Kumar', 'sumit', '12345', 0),
(35, 'Amit', 'Kumar', 'amit', '12345', 0),
(34, 'Aman', 'Singh', 'aman', '12345', 0),
(38, 'Naveen', 'Singh', 'naveensingh', '12345', 0),
(39, 'Suresh', 'Singh', 'suresh', '12345', 0),
(40, 'Naman', 'Kumar', 'namankumar', '12345', 0),
(41, 'Kamal', 'Singh', 'kamal11', '12345', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`post_id`),
  ADD UNIQUE KEY `post_id` (`post_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `post_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
